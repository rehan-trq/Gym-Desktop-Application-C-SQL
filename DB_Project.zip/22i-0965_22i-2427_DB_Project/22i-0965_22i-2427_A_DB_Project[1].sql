create database DB_Project

use DB_Project

create table Admin
(	
	AdminID int Primary Key,
	username varchar(50) unique,
	password varchar(50),
	number varchar(20),
	email varchar(20),
	age int ,
	gender varchar(10)
)

select *
from admin

create table Owner
(
	OwnerID int Primary Key,
	username varchar(50) unique,
	password varchar(50),
	number varchar(20),
	email varchar(20),
	age int ,
	gender varchar(10)
)


select *
from owner

create table Member
(
	MemberID int Primary Key,
	username varchar(50) unique,
	password varchar(50),
	number varchar(20),
	email varchar(20),
	age int ,
	gender varchar(10),
	MemberShipTier varchar(10),
	Weight float,
	Height float
)

delete from member where memberid>50
select *
from member

create table Trainer 
(
	TrainerID int Primary Key,
	username varchar(50) unique,
	password varchar(50),
	number varchar(20),
	email varchar(20),
	age int ,
	gender varchar(10),
	ExperienceinYears int,
	Rating int,
	Speciality varchar(10),
	MemberID int,
	status varchar (10)
	Foreign Key (MemberID) references Member (MemberID)
)

select *
from trainer

create table Gym
(
	GymID int primary key,
	Gymname varchar(20),
	location varchar (20),
	capacity int,
	MembershipFee int,
	OpeningTime varchar(10),
	ClosingTime varchar (10),
	AdminID int ,
	status varchar(10)
	Foreign Key (AdminID) references Admin (AdminID),
	OwnerID int,
	Foreign Key (OwnerID) references Owner (OwnerID)
)
select * from gym

delete from gym where gymid >20

create table WorkoutPlan
(
	WPlanID int Primary Key,
	WorkoutSchedule varchar(50),
	Goal varchar(20),
	ExperienceLevel varchar(20),
	MemberID int,
	TrainerID int,
	Foreign Key(MemberID) references Member (MemberID),
	Foreign Key(TrainerID) references Trainer (TrainerID)
)

delete from WorkoutPlan where WPlanID>50

select * from WorkoutPlan


create table Workout
(
	WorkoutID int Primary Key,
	TargetedMuscle varchar(10),
	WPlanID int,
	Foreign Key (WplanID) references WorkoutPlan (WPlanID)
)


select * from Workout

create table Exercise
(
	ExerciseID int Primary Key,
	Reps int,
	Sets int,
	RestIntervals varchar(20)
)

select * from Exercise

create table WorkoutHasExercise
(
	ExerciseID int ,
	WorkoutID int ,
	Primary Key(ExerciseID, WorkoutID),

	Foreign Key (ExerciseID) references Exercise (ExerciseID),
	Foreign Key (WorkoutID) references Workout (WorkoutID)
)


select * from WorkoutHasExercise

create table Machine
(
	MachineID int Primary Key,
	MachineName varchar (20),
	Company varchar (20),
	TargetedMuscle varchar (20),
	ExerciseID int,
	Foreign Key (ExerciseID) references Exercise (ExerciseID)
)


select * from Machine

create table DietPlan
(
	DPlanID int Primary Key,
	Nutrition varchar (20),
	DietType varchar (20),
	Objective varchar (20),
	MemberID int,
	TrainerID int,
	Foreign Key(MemberID) references Member (MemberID),
	Foreign Key(TrainerID) references Trainer (TrainerID)
)

select * from DietPlan

create table Meal
(
	MealID int Primary Key,
	Calories int,
	Carbohydates int,
	Fibre int, 
	Proteins int, 
	Fats int,
	PotentialAllergens varchar (20),
	PortionSize int,
	MealTime varchar (20),
	DPlanID int,
	Foreign Key (DPlanID) references DietPlan (DPlanID)
)



select *
from meal

create table TrainingSession
(
	SessionID int Primary Key,
	Goal varchar (20),
	StartingTime varchar (20),
	EndingTime varchar (20),
	MemberID int,
	TrainerID int,
	Foreign Key(MemberID) references Member (MemberID),
	Foreign Key(TrainerID) references Trainer (TrainerID)
)

select * from TrainingSession

create table Feedback
(
	FeedbackID int Primary Key,
	Rating int,
	Review varchar (20),
	MemberID int,
	TrainerID int,
	Foreign Key(MemberID) references Member (MemberID),
	Foreign Key(TrainerID) references Trainer (TrainerID)
)

select * from feedback

create table TrainerWorksinGym
(
	GymID int ,
	TrainerID int,
	JoinDate Date,
	Primary Key (GymID, TrainerID),
	Foreign Key (GymID) references Gym (GymID),
	Foreign Key (TrainerID) references Trainer (TrainerID)
)

create table GymHasTrainerRating
(
	GymID int ,
	TrainerID int,
	Rating int,
	Primary Key (GymID, TrainerID),
	Foreign Key (GymID) references Gym (GymID),
	Foreign Key (TrainerID) references Trainer (TrainerID)
)

Select * from GymHasTrainerRating

create table "OwnerAdd/RemoveTrainer"
(
	OwnerID int,
	TrainerID int,
	Primary Key(OwnerID, TrainerID),
	Foreign Key(OwnerID) references Owner(OwnerID),
	Foreign Key(TrainerID) references Trainer(TrainerID)
)


create table MemberWorksoutinGym
(
	GymID int ,
	MemberID int,
	Primary Key (GymID, MemberID),
	Foreign Key (GymID) references Gym (GymID),
	Foreign Key (MemberID) references Member (MemberID) on delete cascade
)


create table "OwnerAdd/RemoveMember"
(
	OwnerID int,
	MemberID int,
	Primary Key(OwnerID, MemberID),
	Foreign Key(OwnerID) references Owner(OwnerID),
	Foreign Key(MemberID) references Member(MemberID)
)

create table audit_trail 
(
	audit_id int identity(1,1) primary key,
	action varchar (50),
	timestamp datetime
)


select *
from audit_trail


create procedure memberreport
as
begin
select * from member
end;

create procedure trainerreport
as
begin
select * from trainer
end;


create procedure usertrainerreport
as
begin


select * from Workout
inner join WorkoutPlan on Workout.WPlanID=WorkoutPlan.WPlanID
inner join WorkoutHasExercise on WorkoutHasExercise.WorkoutID = Workout.WorkoutID
inner join exercise on WorkoutHasExercise.ExerciseID=Exercise.ExerciseID

end;

create procedure usertrainerdpreport
as
begin

select * from DietPlan 
inner join Meal on DietPlan.DPlanID=Meal.DPlanID

end;

create procedure gymfeedback
as
begin
	
	select gym.Gymname, trainer.username, GymHasTrainerRating.Rating
	from GymHasTrainerRating inner join gym on GymHasTrainerRating.GymID=gym.GymID
	inner join Trainer on GymHasTrainerRating.TrainerID=Trainer.TrainerID

end;

create procedure memberfeedback
as
begin

	select member.username, trainer.username, feedback.Rating
	from Feedback inner join member on feedback.MemberID=member.MemberID
	inner join trainer on feedback.TrainerID=trainer.TrainerID
end;

create procedure trainerfeedback
as
begin
	
	select Trainer.username, trainer.Rating
	from Trainer
end;

create procedure viewsession
as
begin
	
	select TrainingSession.Goal, TrainingSession.StartingTime, TrainingSession.EndingTime, Member.username as Member , Trainer.username as Trainer
	from TrainingSession inner join Member on TrainingSession.MemberID=Member.MemberID
	inner join trainer on TrainingSession.TrainerID=trainer.TrainerID
end;

--Triggers

create trigger delete_member
on Member
After Delete
as
begin
	insert into audit_trail values ('Member Deleted', GETDATE());

end;


create trigger delete_trainer
on Trainer
After Delete
as
begin
	insert into audit_trail values ('Trainer Deleted', GETDATE());

end;


create trigger addGym
on Gym
After Insert
as
begin
	insert into audit_trail values ('New Gym Added', GETDATE());

end;

create trigger addGym
on Gym
After Delete
as
begin
	insert into audit_trail values ('Gym Deleted', GETDATE());

end;


create trigger approvetrainer
on Trainer
After Update
as
begin
	insert into audit_trail values ('Trainer Approved', GETDATE());

end;


create trigger approvegym
on Gym
After Update
as
begin
	insert into audit_trail values ('Gym Approved', GETDATE());

end;

create trigger newsession
on TrainingSession
After Insert
as
begin
	insert into audit_trail values ('New Session Created', GETDATE());

end;

create trigger rescheduledsession
on TrainingSession
After Update
as
begin
	insert into audit_trail values ('Session Rescheduled', GETDATE());

end;


create trigger canceledsession
on TrainingSession
After Delete
as
begin
	insert into audit_trail values ('Training Session Canceled', GETDATE());

end;

create trigger newfeedback
on Feedback
After Insert
as
begin
	insert into audit_trail values ('New Feedback given by Member', GETDATE());

end;

create trigger newmachine
on Machine
After Insert
as
begin
	insert into audit_trail values ('New Machine Added', GETDATE());

end;

create trigger newworkout
on Workout
After Insert
as
begin
	insert into audit_trail values ('New Workout Plan Created', GETDATE());

end;

select * from audit_trail

--Reports 

-- Compulsory Reports

--Report 1

create procedure Report1
as
begin

	SELECT m.username as Member, m.email, m.MemberShipTier, t.username as Trainer, g.Gymname
	FROM Member m
	JOIN TrainingSession ts ON m.MemberID = ts.MemberID
	JOIN Trainer t ON ts.TrainerID = t.TrainerID
	JOIN Gym g ON ts.MemberID = g.GymID
	WHERE g.GymID = 5
	AND t.TrainerID = 10;

end;


--Report 2

create procedure Report2
as
begin
	
	SELECT m.username as Member, m.email, m.MemberShipTier, dp.DPlanID, g.Gymname, g.GymID
	FROM Member m
	JOIN DietPlan dp ON m.MemberID = dp.MemberID
	JOIN Gym g ON m.MemberID = g.GymID
	WHERE g.GymID = 15
	AND dp.DPlanID = 25;

end;

--Report 3

create procedure Report3
as
begin
	
	SELECT m.username as Member, m.email, m.MemberShipTier, dp.DPlanID, t.username
	FROM Member m
	JOIN DietPlan dp ON m.MemberID = dp.MemberID
	JOIN Trainer t ON dp.TrainerID = t.TrainerID
	JOIN TrainingSession ts ON m.MemberID = ts.MemberID
	WHERE ts.TrainerID = 17
	AND dp.DPlanID = 48


end;

--Report4

create procedure Report4
as
begin
	
	SELECT COUNT(DISTINCT mw.MemberID) AS MemberCount
	FROM MemberWorksoutinGym mw
	JOIN TrainingSession ts ON mw.MemberID = ts.MemberID
	JOIN Trainer t ON ts.TrainerID = t.TrainerID
	JOIN WorkoutPlan wp ON t.TrainerID = wp.TrainerID
	JOIN Workout w ON wp.WPlanID = w.WPlanID
	JOIN WorkoutHasExercise whe ON w.WorkoutID = whe.WorkoutID
	JOIN Machine ma ON whe.ExerciseID = ma.ExerciseID
	WHERE mw.GymID = 5
	AND ma.MachineID = 10;
end;

--Report 5
create procedure Report5
as
begin
	
	SELECT dp.DPlanID, dp.Nutrition, dp.DietType, dp.Objective, m.Calories, m.MealTime
	FROM DietPlan dp
	JOIN Meal m ON dp.DPlanID = m.DPlanID
	WHERE m.MealTime = ' Breakfast '
	AND m.Calories < 500;
end;

--Report 6
create procedure Report6
as
begin
	
	SELECT dp.DPlanID, dp.Nutrition, dp.Objective, dp.DietType, m.Carbohydates
	FROM DietPlan dp
	JOIN Meal m ON dp.DPlanID = m.DPlanID
	GROUP BY dp.DPlanID,dp.Nutrition, dp.Objective, dp.DietType, m.Carbohydates
	HAVING SUM(m.Carbohydates) < 300;

end;

--Report 7
create procedure Report7
as 
begin

	SELECT distinct wp.WPlanID, wp.WorkoutSchedule,wp.Goal, wp.ExperienceLevel
	FROM WorkoutPlan wp
	JOIN Workout w ON wp.WPlanID = w.WPlanID
	JOIN WorkoutHasExercise whe ON w.WorkoutID = whe.WorkoutID

end;

drop procedure report7

--Report 8
create procedure Report8
as
begin

	SELECT dp.*
	FROM DietPlan dp
	JOIN Meal m ON dp.DPlanID = m.DPlanID
	WHERE m.PotentialAllergens NOT LIKE '%peanuts%'
	OR m.PotentialAllergens IS NULL;

end;

--Report 9
create procedure Report9
as
begin
	
	select Member.username, Member.MemberShipTier, Member.email
	from member 
	where member.MemberShipTier  Like '%Silver%'

end;

--Report 10
create procedure Report10
as
begin
	
	select Member.username, Member.MemberShipTier, gym.Gymname
	from MemberWorksoutinGym inner join member on MemberWorksoutinGym.MemberID=Member.MemberID
	inner join gym on MemberWorksoutinGym.GymID=gym.GymID
	group by gym.Gymname, Member.MemberShipTier, Member.username
	having Member.MemberShipTier like '%Gold%'
		
end;

drop  
--Additional Reports

--Report 1

--List of diet plans with less than 20 grams of fat per meal:

create procedure report11
as
begin

SELECT DietPlan.DPlanID, DietPlan.Nutrition, DietPlan.Objective , meal.fats
FROM DietPlan
JOIN meal ON DietPlan.DPlanID = meal.DPlanID
WHERE meal.fats < 20;

end


--List of diet plans with more than 200 grams Portion Size

create procedure report12
as
begin

SELECT dp.DPlanID, dp.Nutrition, dp.Objective, m.PortionSize
FROM DietPlan dp
join meal m on dp.DPlanID=m.DPlanID
where m.PortionSize>250;

end;


--List of diet plans designed for weight loss

create procedure Report13
as
begin

SELECT dp.DPlanID, dp.Nutrition, dp.Objective
FROM DietPlan dp
WHERE dp.objective = ' Weight Loss  ';

end;

--Diet plans with total carbohydrate intake less than 350 grams and total fiber intake greater than 60 grams
create procedure Report14
as
begin

SELECT dp.DPlanID, dp.Nutrition, dp.DietType, dp.Objective, m.Carbohydates, m.Fibre
FROM DietPlan dp
INNER JOIN Meal m ON dp.DPlanID = m.DPlanID
GROUP BY dp.DPlanID, dp.Nutrition, dp.DietType, dp.Objective, m.Carbohydates, m.Fibre
HAVING SUM(m.Carbohydates) < 350 AND SUM(m.Fibre) > 5;

end;

--List of workout plans for beginners

create procedure Reprot15
as
begin

SELECT wp.WPlanID, wp.ExperienceLevel, wp.Goal, wp.WorkoutSchedule
FROM WorkoutPlan wp
WHERE wp.ExperienceLevel = ' Beginner ';

end;


--List of workout plans targeting abs and core muscles

create procedure Report16
as
begin

SELECT wp.WPlanID, wp.Goal, wp.ExperienceLevel, w.TargetedMuscle
FROM WorkoutPlan wp
JOIN Workout w ON wp.WPlanID = w.WPlanID
WHERE w.TargetedMuscle = ' Chest ';

end;

-- List of trainers with a rating above 4.5

create procedure Report17
as
begin

SELECT t.TrainerID, t.username ,t.ExperienceinYears, t.Speciality, t.age, AVG(f.Rating) AS avg_rating
FROM Trainer t
JOIN Feedback f ON t.TrainerID = f.TrainerID
GROUP BY t.TrainerID, t.username, t.ExperienceinYears, t.Speciality, t.age
HAVING AVG(f.Rating) > 4.5;

end;

--List of gyms where the average member age is below 30

create procedure Report18
as
begin

SELECT g.GymID, g.Gymname, g.location, g.MembershipFee,g.capacity, AVG(member.age) AS avg_age
FROM MemberWorksoutinGym m
JOIN Gym g ON g.GymID = m.GymID
join Member on Member.MemberID=m.MemberID
GROUP BY g.GymID , g.Gymname, g.location, g.MembershipFee,g.capacity
HAVING AVG(member.age) < 30;

end;

--Diet plans which don�t have gluten as allergens and objective is maintaining weight:

create procedure Report19
as
begin

SELECT dp.DPlanID, dp.Nutrition, dp.DietType, dp.Objective, m.PotentialAllergens
FROM DietPlan dp
INNER JOIN Meal m ON dp.DPlanID = m.DPlanID
WHERE m.PotentialAllergens NOT LIKE '%Gluten%' AND dp.Objective = ' Maintain';

end;

-- Diet plans with less than 400 calorie meals as lunch 

create procedure Report20
as
begin

SELECT dp.DPlanID, dp.Nutrition, dp.DietType, dp.Objective, m.MealTime
FROM DietPlan dp
INNER JOIN Meal m ON dp.DPlanID = m.DPlanID
WHERE m.MealTime = ' Lunch ' AND m.Calories < 400 


end;
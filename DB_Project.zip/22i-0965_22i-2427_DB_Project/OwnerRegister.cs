﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Proj
{
    public partial class OwnerRegister : Form
    {
        public OwnerRegister()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            OwnerLogin h = new OwnerLogin();
            h.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random memberid = new Random();
            int randomnumber = memberid.Next(21, 100);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                string un = textBox1.Text;
                string pass = textBox2.Text;
                string email = textBox3.Text;
                string number = textBox4.Text;
                int age = Convert.ToInt32(textBox6.Text);
                string gender = comboBox1.Text;

                string query = "INSERT INTO Owner (ownerid, username, Password, email, number , age, gender) VALUES (@MemberID, @Username, @Password, @Email, @Number, @Age,  @Gender)";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@MemberID", randomnumber);
                    cm.Parameters.AddWithValue("@Username", un);
                    cm.Parameters.AddWithValue("@Password", pass);
                    cm.Parameters.AddWithValue("@Email", email);
                    cm.Parameters.AddWithValue("@Number", number);
                    cm.Parameters.AddWithValue("@Age", age);
                    cm.Parameters.AddWithValue("@Gender", gender);

                    cm.ExecuteNonQuery();
                }

            }

            this.Hide();
            OwnerLogin o = new OwnerLogin();
            o.Show();


        }
    }
}

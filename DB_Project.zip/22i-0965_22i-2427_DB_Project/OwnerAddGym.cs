﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Proj
{
    public partial class OwnerAddGym : Form
    {
        public OwnerAddGym()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Owner h = new Owner();
            h.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int randomGymID = random.Next(31, 100);

            string gymName = textBox1.Text;
            int membershipFee = Convert.ToInt32(textBox2.Text);
            int capacity = Convert.ToInt32(textBox3.Text);
            string location = textBox4.Text;
            string openingTime = textBox5.Text;
            string closingTime = textBox6.Text;
            string status = "Pending";
            Random r = new Random();
            int adminID = r.Next(1, 5);

            Random r1 = new Random();
            int ownerID = r1.Next(1, 30);

            string query = @"INSERT INTO Gym (GymID, Gymname, location, capacity, MembershipFee, OpeningTime, ClosingTime, AdminID,status, OwnerID) 
                         VALUES (@GymID, @Gymname, @Location, @Capacity, @MembershipFee, @OpeningTime, @ClosingTime, @AdminID,@status, @OwnerID)";

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@GymID", randomGymID);
                    command.Parameters.AddWithValue("@Gymname", gymName);
                    command.Parameters.AddWithValue("@Location", location);
                    command.Parameters.AddWithValue("@Capacity", capacity);
                    command.Parameters.AddWithValue("@MembershipFee", membershipFee);
                    command.Parameters.AddWithValue("@OpeningTime", openingTime);
                    command.Parameters.AddWithValue("@ClosingTime", closingTime);
                    command.Parameters.AddWithValue("@AdminID", adminID);
                    command.Parameters.AddWithValue("@status", status);
                    command.Parameters.AddWithValue("@OwnerID", ownerID);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data inserted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to insert data.");
                    }
                }
            }

            this.Hide();
            Owner o = new Owner();
            o.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class ViewGym : Form
    {
        public ViewGym()
        {
            InitializeComponent();
        }

        private void ViewGym_Load(object sender, EventArgs e)
        {
            DB_Proj.vigym g = new DB_Proj.vigym();

            string connectionString = "Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("displaygym", connection);
                command.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                try
                {

                    connection.Open();

                    adapter.Fill(g.displaygym);

                    reportViewer1.LocalReport.ReportPath = @"D:\Semester 4\DB\Project\DB_Proj\DB_Proj\VGym.rdlc";
                    reportViewer1.LocalReport.DataSources.Clear();
                    reportViewer1.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource("ViewGym", g.Tables[0]));

                    reportViewer1.RefreshReport();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberRegister m = new MemberRegister();
            m.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();
                string un = textBox2.Text;
                string gymname = textBox1.Text;
                string query = "Select memberid from Member where Username like  '" + un + "' ";
                string query2 = "Select gymid from Gym where Gymname like  '" + gymname + "' ";
                SqlCommand com;
                com = new SqlCommand(query, conn);
                object var1 = com.ExecuteScalar();
                int member = (int)var1;

                SqlCommand com2;
                com2 = new SqlCommand(query2, conn);
                object var2 = com2.ExecuteScalar();
                int gymid = (int)var2;

                string query1 = "Insert into MemberWorksoutinGym (GymID, MemberID) values (@GymID, @MemberID)";

                using (SqlCommand cm = new SqlCommand(query1, conn))
                {
                    cm.Parameters.AddWithValue("@GymID", gymid);
                    cm.Parameters.AddWithValue("@MemberID", member);

                    cm.ExecuteNonQuery();
                    MessageBox.Show("Successful");
                }
            }   

            this.Hide();
            Member m = new Member();
            m.Show();
        }
    }
}

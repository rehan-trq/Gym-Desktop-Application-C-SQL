﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class OwnerLogin : Form
    {
        public OwnerLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False");
            conn.Open();
            string un = textBox1.Text;
            string pass = textBox2.Text;
            string query = "Select Password from Owner where Username like  '" + un + "' ";
            SqlCommand com;
            com = new SqlCommand(query, conn);
            object var1 = com.ExecuteScalar();
            if (var1 != null)
            {
                if (var1.ToString() == pass)
                {
                    this.Hide();
                    Owner O = new Owner();
                    O.Show();
                }
                else
                {
                    MessageBox.Show("Incorrect Password");
                }
            }

            else
            {
                MessageBox.Show("Username Does not exist");
            }
            conn.Close();           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            OwnerRegister O = new OwnerRegister();
            O.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

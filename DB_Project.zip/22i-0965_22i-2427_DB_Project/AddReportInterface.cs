﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class AddReportInterface : Form
    {
        public AddReportInterface()
        {
            InitializeComponent();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReportHome r = new ReportHome();
            r.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report11 r = new Report11();    
            r.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report12 r = new Report12();
            r.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report13 r = new Report13();
            r.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report14 r = new Report14();
            r.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report15 r = new Report15();
            r.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report16 r = new Report16();
            r.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report17 r = new Report17();
            r.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report18 r = new Report18();
            r.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report19 r = new Report19();
            r.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report20 r = new Report20();
            r.Show();
        }
    }
}

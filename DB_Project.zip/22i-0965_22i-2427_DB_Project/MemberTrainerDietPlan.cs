﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class MemberTrainerDietPlan : Form
    {
        public MemberTrainerDietPlan()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberDietPlans m = new MemberDietPlans();
            m.Show();
        }

        private void MemberTrainerDietPlan_Load(object sender, EventArgs e)
        {
            DB_Proj.Data_usertrainerDP reportData = new DB_Proj.Data_usertrainerDP();

            string connectionString = "Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("usertrainerdpreport", connection);
                command.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                try
                {

                    connection.Open();

                    adapter.Fill(reportData.usertrainerdpreport);

                    reportViewer1.LocalReport.ReportPath = @"D:\Semester 4\DB\Project\DB_Proj\DB_Proj\Report_UserTrainerDP.rdlc";
                    reportViewer1.LocalReport.DataSources.Clear();
                    reportViewer1.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource("UserTrainerReport", reportData.Tables[0]));

                    reportViewer1.RefreshReport();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
    }
}

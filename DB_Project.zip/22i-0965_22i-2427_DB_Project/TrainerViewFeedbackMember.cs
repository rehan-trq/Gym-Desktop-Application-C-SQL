﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class TrainerViewFeedbackMember : Form
    {
        public TrainerViewFeedbackMember()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerViewFeedback t = new TrainerViewFeedback();
            t.Show();
        }

        private void TrainerViewFeedbackMember_Load(object sender, EventArgs e)
        {
            DB_Proj.Data_MemberFeedback reportData = new DB_Proj.Data_MemberFeedback();

            string connectionString = "Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("memberfeedback", connection);
                command.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter adapter = new SqlDataAdapter(command);

                try
                {

                    connection.Open();

                    adapter.Fill(reportData.memberfeedback);

                    reportViewer1.LocalReport.ReportPath = @"D:\Semester 4\DB\Project\DB_Proj\DB_Proj\Report_MemberFeedback.rdlc";
                    reportViewer1.LocalReport.DataSources.Clear();
                    reportViewer1.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource("MemberFeedback", reportData.Tables[0]));

                    reportViewer1.RefreshReport();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
    }
}

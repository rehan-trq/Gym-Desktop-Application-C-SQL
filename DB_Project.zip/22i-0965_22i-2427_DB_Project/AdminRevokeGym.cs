﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class AdminRevokeGym : Form
    {
        public AdminRevokeGym()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin h = new Admin();
            h.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                string un = textBox1.Text;
                string ownername = textBox2.Text;

                string query1 = "SELECT gymid FROM Gym WHERE Gymname LIKE  @Gymname";

                SqlCommand com = new SqlCommand(query1, conn);
                com.Parameters.AddWithValue("@Gymname", un);
                object var1 = com.ExecuteScalar();

                if (var1 != null)
                {
                    string queryDelete = "DELETE FROM Gym WHERE Gymname LIKE @Gymname";
                    SqlCommand deleteCommand = new SqlCommand(queryDelete, conn);
                    deleteCommand.Parameters.AddWithValue("@Gymname", un);
                    deleteCommand.ExecuteNonQuery();
                    MessageBox.Show("Gym deleted successfully.");

                }
                else
                {
                    MessageBox.Show("No Gym found with the provided Name.");
                }

            }

            this.Hide();
            Admin a = new Admin();
            a.Show();
        }

        private void AdminRevokeGym_Load(object sender, EventArgs e)
        {

        }
    }
}

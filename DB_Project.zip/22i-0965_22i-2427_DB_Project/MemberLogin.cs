﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class MemberLogin : Form
    {
        public MemberLogin()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False");
            conn.Open();
            string un = textBox1.Text;
            string pass = textBox2.Text;
            string query = "Select Password from Member where Username like  '" + un + "' ";
            SqlCommand com;
            com = new SqlCommand(query, conn);
            object var1 = com.ExecuteScalar();
            if (var1 != null)
            {
                if (var1.ToString() == pass)
                {
                    this.Hide();
                    Member M = new Member();
                    M.Show();
                }
                else
                {
                    MessageBox.Show("Incorrect Password");
                }
            }

            else
            {
                MessageBox.Show("Username Does not exist");
            }
            conn.Close();            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberRegister M = new MemberRegister();
            M.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home m = new Home();
            m.Show();
        }
    }
}

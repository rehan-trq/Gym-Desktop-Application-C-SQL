﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class MemberTrainingSession : Form
    {
        public MemberTrainingSession()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Member m = new Member();
            m.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random trainerid = new Random();
            int randomnumber1 = trainerid.Next(1, 50);

            Random sessionid = new Random();
            int randomnumber2 = sessionid.Next(31, 50);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                string goal = textBox1.Text;
                string starttime = textBox3.Text;
                string endtime = textBox2.Text;
                string name = textBox4.Text;

                string query1 = "SELECT MemberID FROM Member WHERE username LIKE  @username";

                SqlCommand com = new SqlCommand(query1, conn);
                com.Parameters.AddWithValue("@username", name);
                object var1 = com.ExecuteScalar();

                if (var1 != null)
                {
                    int memberid = (int)var1;

                    string query = "INSERT INTO TrainingSession (SessionID, Goal, StartingTime,EndingTime, MemberID, TrainerID) VALUES (@SessionID, @Goal, @StartingTime, @EndingTime, @MemberID, @TrainerID)";

                    using (SqlCommand cm = new SqlCommand(query, conn))
                    {

                        cm.Parameters.AddWithValue("@SessionID", randomnumber2);
                        cm.Parameters.AddWithValue("@Goal", goal);
                        cm.Parameters.AddWithValue("@StartingTime", starttime);
                        cm.Parameters.AddWithValue("@EndingTime", endtime);
                        cm.Parameters.AddWithValue("@MemberID", memberid);
                        cm.Parameters.AddWithValue("@TrainerID", randomnumber1);


                        cm.ExecuteNonQuery();
                    }
                }
            }
            this.Hide();
            Member m = new Member();
            m.Show();
        }
    }
}

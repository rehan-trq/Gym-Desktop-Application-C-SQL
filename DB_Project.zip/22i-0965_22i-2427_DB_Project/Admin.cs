﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {

         //   this.reportViewer1.RefreshReport();
           // this.reportViewer1.RefreshReport();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminApproveGym S = new AdminApproveGym();
            S.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminGymPerformance S = new AdminGymPerformance();
            S.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminRevokeGym S = new AdminRevokeGym();
            S.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }
    }
}

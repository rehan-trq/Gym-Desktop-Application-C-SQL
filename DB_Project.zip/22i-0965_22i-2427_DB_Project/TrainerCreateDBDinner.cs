﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class TrainerCreateDBDinner : Form
    {
        public TrainerCreateDBDinner()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerCreateDietPlan t = new TrainerCreateDietPlan();
            t.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random dplanid = new Random();
            int randomnumber = dplanid.Next(1, 50);

            Random mealid = new Random();
            int randomnumber1 = mealid.Next(51, 100);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();


                string fibre = textBox1.Text;
                string portionsize = textBox2.Text;
                string protein = textBox3.Text;
                string allergen = textBox4.Text;
                string carbohydrates = textBox5.Text;
                string mealtime = textBox6.Text;
                string calories = textBox8.Text;
                string fats = textBox9.Text;



                string query = "INSERT INTO Meal (MealID, Calories, Carbohydrates, Fibre , Proteins, Fats, PotentialAllergens, PortionSize, MealTime, DPlanID) VALUES (@MealID, @Calories, @Carbohydrates, @Fibre , @Proteins, @Fats, @PotentialAllergens, @PortionSize, @MealTime, @DPlanID)";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {

                    cm.Parameters.AddWithValue("@MealID", randomnumber1);
                    cm.Parameters.AddWithValue("@Calories", calories);
                    cm.Parameters.AddWithValue("@Carbohydrates", carbohydrates);
                    cm.Parameters.AddWithValue("@Fibre", fibre);
                    cm.Parameters.AddWithValue("@Proteins", protein);
                    cm.Parameters.AddWithValue("@Fats", fats);
                    cm.Parameters.AddWithValue("@PotentialAllergens", allergen);
                    cm.Parameters.AddWithValue("@PortionSize", portionsize);
                    cm.Parameters.AddWithValue("@MealTime", mealtime);
                    cm.Parameters.AddWithValue("@DPlanID", randomnumber);


                    cm.ExecuteNonQuery();
                }
            }

            this.Hide();
            TrainerCreateDietPlan trainerCreateDietPlan = new TrainerCreateDietPlan();
            trainerCreateDietPlan.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DB_Proj
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberLogin M = new MemberLogin();
            M.Show();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerLogin T = new TrainerLogin();
            T.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            OwnerLogin O = new OwnerLogin();
            O.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminLogin A = new AdminLogin();
            A.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReportHome r = new ReportHome();
            r.Show();
        }
    }
}

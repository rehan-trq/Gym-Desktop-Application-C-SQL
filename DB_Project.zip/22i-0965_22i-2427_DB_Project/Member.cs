﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class Member : Form
    {
        public Member()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberWorkoutPlan WP = new MemberWorkoutPlan();
            WP.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberDietPlans DP = new MemberDietPlans();
            DP.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberTrainingSession TS = new MemberTrainingSession();
            TS.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberFeedback FD = new MemberFeedback();
            FD.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void Member_Load(object sender, EventArgs e)
        {

        }
    }
}

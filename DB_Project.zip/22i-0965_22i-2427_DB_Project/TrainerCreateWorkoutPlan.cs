﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class TrainerCreateWorkoutPlan : Form
    {
        public TrainerCreateWorkoutPlan()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random wplanid = new Random();
            int randomnumber = wplanid.Next(51, 70);

            Random memberid = new Random();
            int randomnumber1 = memberid.Next(1, 50);

            Random trainerid = new Random();
            int randomnumber2 = trainerid.Next(1, 30);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                string goal = textBox1.Text;
                string exlevel = textBox2.Text;

                string query = "INSERT INTO WorkoutPlan (WPlanID, Goal, ExperienceLevel, MemberID, TrainerID) VALUES (@WPlanID, @Goal, @ExperienceLevel, @MemberID, @TrainerID)";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@WPlanID", randomnumber);
                    cm.Parameters.AddWithValue("@Goal", goal);
                    cm.Parameters.AddWithValue("@ExperienceLevel", exlevel);
                    cm.Parameters.AddWithValue("@MemberID", randomnumber1);
                    cm.Parameters.AddWithValue("@TrainerID", randomnumber2);


                    cm.ExecuteNonQuery();
                }
            }

            this.Hide();
            TrainerWorkoutSchedule S = new TrainerWorkoutSchedule();
            S.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Trainer t = new Trainer();
            t.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class MemberRegister : Form
    {
        int x = 50;
        public MemberRegister()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random memberid = new Random();
            int randomnumber = memberid.Next(51, 100);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                string un = textBox1.Text;
                string pass = textBox2.Text;
                string email = textBox3.Text;
                string number = textBox4.Text;
                string tier = textBox5.Text;
                int age = Convert.ToInt32(textBox6.Text);
                float height = Convert.ToSingle(textBox7.Text);
                float weight = Convert.ToSingle(textBox8.Text);
                string gender = comboBox1.Text;

                string query = "INSERT INTO Member (memberid, username, Password, email, number, membershiptier, age, height, weight, gender) VALUES (@MemberID, @Username, @Password, @Email, @Number, @MembershipTier, @Age, @Height, @Weight, @Gender)";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@MemberID", randomnumber);
                    cm.Parameters.AddWithValue("@Username", un);
                    cm.Parameters.AddWithValue("@Password", pass);
                    cm.Parameters.AddWithValue("@Email", email);
                    cm.Parameters.AddWithValue("@Number", number);
                    cm.Parameters.AddWithValue("@MembershipTier", tier);
                    cm.Parameters.AddWithValue("@Age", age);
                    cm.Parameters.AddWithValue("@Height", height);
                    cm.Parameters.AddWithValue("@Weight", weight);
                    cm.Parameters.AddWithValue("@Gender", gender);

                    cm.ExecuteNonQuery();
                }
            }



            this.Hide();
            ViewGym M = new ViewGym();
            M.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberLogin m = new MemberLogin();
            m.Show();
        }

        private void MemberRegister_Load(object sender, EventArgs e)
        {

        }
    }
}

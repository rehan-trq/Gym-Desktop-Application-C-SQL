﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace DB_Proj
{
    public partial class MemberCreateDietPlan : Form
    {
        public MemberCreateDietPlan()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random dplanid = new Random();
            int randomnumber = dplanid.Next(50, 70);

            Random memberid = new Random();
            int randomnumber1 = memberid.Next(1, 50);

            Random trainerid = new Random();
            int randomnumber2 = trainerid.Next(1, 30);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                
                string type = textBox1.Text;
                string objective = textBox3.Text;
                string nutrition = textBox7.Text;



                string query = "INSERT INTO DietPlan (DPlanID, Nutrition, DietType, Objective , MemberID, TrainerID) VALUES (@DPlanID, @Nutrition, @DietType, @Objective, @MemberID, @TrainerID)";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {

                    cm.Parameters.AddWithValue("@DPlanID", randomnumber);
                    cm.Parameters.AddWithValue("@Nutrition", nutrition);
                    cm.Parameters.AddWithValue("@DietType", type);
                    cm.Parameters.AddWithValue("@Objective", objective);
                    cm.Parameters.AddWithValue("@MemberID", randomnumber1);
                    cm.Parameters.AddWithValue("@TrainerID", randomnumber2);


                    cm.ExecuteNonQuery();
                }
            }
            this.Hide();
            MemberCreateDPBreakfast S = new MemberCreateDPBreakfast();
            S.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random dplanid = new Random();
            int randomnumber = dplanid.Next(50, 70);

            Random memberid = new Random();
            int randomnumber1 = memberid.Next(1, 50);

            Random trainerid = new Random();
            int randomnumber2 = trainerid.Next(1, 30);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();


                string type = textBox1.Text;
                string objective = textBox3.Text;
                string nutrition = textBox7.Text;



                string query = "INSERT INTO DietPlan (DPlanID, Nutrition, DietType, Objective , MemberID, TrainerID) VALUES (@DPlanID, @Nutrition, @DietType, @Objective, @MemberID, @TrainerID)";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {

                    cm.Parameters.AddWithValue("@DPlanID", randomnumber);
                    cm.Parameters.AddWithValue("@Nutrition", nutrition);
                    cm.Parameters.AddWithValue("@DietType", type);
                    cm.Parameters.AddWithValue("@Objective", objective);
                    cm.Parameters.AddWithValue("@MemberID", randomnumber1);
                    cm.Parameters.AddWithValue("@TrainerID", randomnumber2);


                    cm.ExecuteNonQuery();
                }
            }

            this.Hide();
            MemberCreateDPLunch S = new MemberCreateDPLunch();
            S.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Random dplanid = new Random();
            int randomnumber = dplanid.Next(50, 70);

            Random memberid = new Random();
            int randomnumber1 = memberid.Next(1, 50);

            Random trainerid = new Random();
            int randomnumber2 = trainerid.Next(1, 30);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();


                string type = textBox1.Text;
                string objective = textBox3.Text;
                string nutrition = textBox7.Text;



                string query = "INSERT INTO DietPlan (DPlanID, Nutrition, DietType, Objective , MemberID, TrainerID) VALUES (@DPlanID, @Nutrition, @DietType, @Objective, @MemberID, @TrainerID)";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {

                    cm.Parameters.AddWithValue("@DPlanID", randomnumber);
                    cm.Parameters.AddWithValue("@Nutrition", nutrition);
                    cm.Parameters.AddWithValue("@DietType", type);
                    cm.Parameters.AddWithValue("@Objective", objective);
                    cm.Parameters.AddWithValue("@MemberID", randomnumber1);
                    cm.Parameters.AddWithValue("@TrainerID", randomnumber2);


                    cm.ExecuteNonQuery();
                }
            }

            this.Hide();
            MemberCreateDPDinner S = new MemberCreateDPDinner();
            S.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberDietPlans h = new MemberDietPlans();
            h.Show();
        }
    }
}

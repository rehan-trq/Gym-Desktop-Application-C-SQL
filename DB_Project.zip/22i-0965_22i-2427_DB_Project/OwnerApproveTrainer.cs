﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class OwnerApproveTrainer : Form
    {
        public OwnerApproveTrainer()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Owner h = new Owner();
            h.Show();
        }

        //private void button2_Click(object sender, EventArgs e)
        //{
        //    using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
        //    {
        //        conn.Open();

        //        string un = textBox1.Text;
        //        string number = textBox2.Text;

        //        string query1 = "Select trainerid from Trainer where Username like  '" + un + "' ";

        //        SqlCommand com;
        //        com = new SqlCommand(query1, conn);
        //        object var1 = com.ExecuteScalar();
        //        int member = (int)var1;
        //        string query = "UPDATE Trainer SET status = @Status where trainerid = @TrainerID";



        //        string status = "Approved";

        //        using (SqlCommand cm = new SqlCommand(query, conn))
        //        {
        //            cm.Parameters.AddWithValue("@Status", status);
        //            cm.ExecuteNonQuery();
        //        }
        //    }

        //    this.Hide();
        //    Owner o = new Owner();
        //    o.Show();
        //}

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                string un = textBox1.Text;
                string number = textBox2.Text;

                string query1 = "SELECT trainerid FROM Trainer WHERE Username LIKE  @Username";

                SqlCommand com = new SqlCommand(query1, conn);
                com.Parameters.AddWithValue("@Username", un);
                object var1 = com.ExecuteScalar();

                if (var1 != null)
                {
                    int trainerId = (int)var1;
                    string query = "UPDATE Trainer SET status = @Status WHERE trainerid = @TrainerID";

                    string status = "Approved";

                    using (SqlCommand cm = new SqlCommand(query, conn))
                    {
                        cm.Parameters.AddWithValue("@Status", status);
                        cm.Parameters.AddWithValue("@TrainerID", trainerId);
                        cm.ExecuteNonQuery();
                    }
                }
                else
                {
                    // Handle the case where no trainer is found with the provided username
                    MessageBox.Show("No trainer found with the provided username.");
                }
            }

            this.Hide();
            Owner o = new Owner();
            o.Show();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Proj
{
    public partial class OwnerAddTrainer : Form
    {
        public OwnerAddTrainer()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Owner h = new Owner();
            h.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random memberid = new Random();
            int randomnumber = memberid.Next(31, 100);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                string un = textBox1.Text;
                string pass = textBox2.Text;
                string email = textBox3.Text;
                string number = textBox4.Text;
                string experience = textBox5.Text;
                int age = Convert.ToInt32(textBox6.Text);
                string speciality = textBox7.Text;
                string gender = comboBox1.Text;
                int rating = Convert.ToInt32(comboBox2.Text);
                string status = "Approved";

                string query = "INSERT INTO Trainer (trainerid, username, Password, email, number, experienceinyears, age, gender, speciality, rating, status) VALUES (@TrainerID, @Username, @Password, @Email, @Number, @ExperienceinYears, @Age, @Gender, @Speciality, @Rating, @Status)";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@Trainerid", randomnumber);
                    cm.Parameters.AddWithValue("@Username", un);
                    cm.Parameters.AddWithValue("@Password", pass);
                    cm.Parameters.AddWithValue("@Email", email);
                    cm.Parameters.AddWithValue("@Number", number);
                    cm.Parameters.AddWithValue("@ExperienceinYears", experience);
                    cm.Parameters.AddWithValue("@Age", age);
                    cm.Parameters.AddWithValue("@Gender", gender);
                    cm.Parameters.AddWithValue("@Speciality", speciality);
                    cm.Parameters.AddWithValue("@Rating", rating);
                    cm.Parameters.AddWithValue("@Status", status);

                    cm.ExecuteNonQuery();
                }
            }

            this.Hide();
            TrainerLogin T = new TrainerLogin();
            T.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Proj
{
    public partial class MemberFeedback : Form
    {
        public MemberFeedback()
        {
            InitializeComponent();
        }

        private void MemberFeedback_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberDietPlans m = new MemberDietPlans();
            m.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random memberid = new Random();
            int randomnumber1 = memberid.Next(1, 50);

            Random feedbackid = new Random();
            int randomnumber2 = feedbackid.Next(51, 70);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                int rating = Convert.ToInt32(comboBox1.Text);
                string review = textBox1.Text;
                string trainername = textBox3.Text;

                string query1 = "SELECT TrainerID FROM Trainer WHERE username LIKE  @username";

                SqlCommand com = new SqlCommand(query1, conn);
                com.Parameters.AddWithValue("@username", trainername);
                object var1 = com.ExecuteScalar();

                if (var1 != null)
                {
                    int trainerid = (int)var1;

                    string query = "INSERT INTO Feedback (FeedbackID, Rating, Review , MemberID, TrainerID) VALUES (@FeedbackID, @Rating, @Review, @MemberID, @TrainerID)";

                    using (SqlCommand cm = new SqlCommand(query, conn))
                    {

                        cm.Parameters.AddWithValue("@FeedbackID", randomnumber2);
                        cm.Parameters.AddWithValue("@Rating", rating);
                        cm.Parameters.AddWithValue("@Review", review);
                        cm.Parameters.AddWithValue("@MemberID", randomnumber1);
                        cm.Parameters.AddWithValue("@TrainerID", trainerid);


                        cm.ExecuteNonQuery();
                    }

                    MessageBox.Show("Feedback Given Successfully");
                }

                else
                {
                    MessageBox.Show("No Trainer with this username exists.");
                }


            }
            this.Hide();
            Member member = new Member();
            member.Show();
        }
    }
}

﻿namespace DB_Proj
{


    partial class products_ds
    {
        partial class productsDataTable
        {
        }

        partial class prDataTable
        {
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class ReportInterface : Form
    {
        public ReportInterface()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report3 r = new Report3();
            r.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReportHome h = new ReportHome();
            h.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report1 r = new Report1();
            r.Show();   
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report2cs r = new Report2cs();
            r.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report4 r = new Report4();
            r.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report5 r = new Report5();
            r.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report6 r = new Report6();
            r.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report7 r = new Report7();
            r.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report8 r = new Report8();
            r.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report9 r = new Report9();
            r.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report10 r = new Report10();
            r.Show();
        }
    }
}

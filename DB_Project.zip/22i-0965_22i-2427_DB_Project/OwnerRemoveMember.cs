﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class OwnerRemoveMember : Form
    {
        public OwnerRemoveMember()
        {
            InitializeComponent();
        }

        private void OwnerRemoveMember_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Owner h = new Owner();
            h.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                string un = textBox1.Text;
                string number = textBox2.Text;

                string query1 = "SELECT memberid FROM Member WHERE Username LIKE  @Username";

                SqlCommand com = new SqlCommand(query1, conn);
                com.Parameters.AddWithValue("@Username", un);
                object var1 = com.ExecuteScalar();

                if (var1 != null)
                {
                        string queryDelete = "DELETE FROM Member WHERE Username LIKE @Username";
                        SqlCommand deleteCommand = new SqlCommand(queryDelete, conn);
                        deleteCommand.Parameters.AddWithValue("@Username", un);
                        deleteCommand.ExecuteNonQuery();
                        MessageBox.Show("Member deleted successfully.");
                  
                }
                else
                {
                    MessageBox.Show("No Member found with the provided username.");
                }

            }
            this.Hide();
            Owner o = new Owner();  
            o.Show();
        }
    }
}

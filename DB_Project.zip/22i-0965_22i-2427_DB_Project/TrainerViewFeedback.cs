﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class TrainerViewFeedback : Form
    {
        public TrainerViewFeedback()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            TrainerViewFeedbackOverall T = new TrainerViewFeedbackOverall();
            T.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            TrainerViewFeedbackGym T = new TrainerViewFeedbackGym();
            T.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            TrainerViewFeedbackMember T = new TrainerViewFeedbackMember();
            T.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Trainer t = new Trainer();
            t.Show();
        }

        private void TrainerViewFeedback_Load(object sender, EventArgs e)
        {

        }
    }
}

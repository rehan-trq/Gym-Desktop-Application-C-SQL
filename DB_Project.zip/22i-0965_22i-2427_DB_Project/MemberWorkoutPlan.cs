﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class MemberWorkoutPlan : Form
    {
        public MemberWorkoutPlan()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberCreateWorkoutPlans M = new MemberCreateWorkoutPlans();
            M.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberUserWorkoutPlan U = new MemberUserWorkoutPlan();
            U.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberTrainerWorkoutPlan T = new MemberTrainerWorkoutPlan();
            T.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Member m = new Member();
            m.Show();
        }
    }
}

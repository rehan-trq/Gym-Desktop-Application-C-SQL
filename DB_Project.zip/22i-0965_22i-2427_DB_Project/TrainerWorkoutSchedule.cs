﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class TrainerWorkoutSchedule : Form
    {
        public TrainerWorkoutSchedule()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerWPSaturday S = new TrainerWPSaturday();
            S.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerWpSunday S = new TrainerWpSunday();
            S.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerWpMonday S = new TrainerWpMonday();
            S.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerWpTuesday S = new TrainerWpTuesday();
            S.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerWpWednesday S = new TrainerWpWednesday();
            S.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerWpThursday S = new TrainerWpThursday();
            S.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerWpFriday S = new TrainerWpFriday();
            S.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerCreateWorkoutPlan t = new TrainerCreateWorkoutPlan();
            t.Show();
        }
    }
}

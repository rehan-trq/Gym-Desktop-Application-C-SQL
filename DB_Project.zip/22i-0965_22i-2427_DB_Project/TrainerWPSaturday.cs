﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class TrainerWPSaturday : Form
    {
        public TrainerWPSaturday()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerWorkoutSchedule t = new TrainerWorkoutSchedule();
            t.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random wplanid = new Random();
            int randomnumber = wplanid.Next(1, 50);

            Random workoutid = new Random();
            int randomnumber1 = workoutid.Next(51, 100);

            Random exerciseid = new Random();
            int randomnumber2 = exerciseid.Next(50, 100);

            Random machineid = new Random();
            int randomnumber3 = machineid.Next(30, 100);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GNASS3J\\SQLEXPRESS01;Initial Catalog=DB_Project;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();

                string reps = textBox1.Text;
                string muscle = textBox2.Text;
                string sets = textBox3.Text;
                string machine = textBox5.Text;
                string restineterval = textBox4.Text;

                string query = "INSERT INTO Workout (WorkoutID, TargetedMuscle, WPlanID) VALUES (@WorkoutID, @TargetedMuscle, @WPlanID)";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@WorkoutID", randomnumber1);
                    cm.Parameters.AddWithValue("@TargetedMuscle", muscle);
                    cm.Parameters.AddWithValue("@WPlanID", randomnumber);


                    cm.ExecuteNonQuery();
                }

                string query1 = "INSERT INTO Exercise (ExerciseID, Reps, Sets, RestIntervals) VALUES (@ExerciseID, @Reps, @Sets, @RestIntervals)";

                using (SqlCommand cm = new SqlCommand(query1, conn))
                {
                    cm.Parameters.AddWithValue("@ExerciseID", randomnumber2);
                    cm.Parameters.AddWithValue("@Reps", reps);
                    cm.Parameters.AddWithValue("@Sets", sets);
                    cm.Parameters.AddWithValue("@RestIntervals", restineterval);


                    cm.ExecuteNonQuery();
                }

                string query2 = "INSERT INTO WorkoutHasExercise (ExerciseID, WorkoutID) VALUES (@ExerciseID, @WorkoutID)";
                using (SqlCommand cm = new SqlCommand(query2, conn))
                {
                    cm.Parameters.AddWithValue("@ExerciseID", randomnumber2);
                    cm.Parameters.AddWithValue("@WorkoutID", randomnumber1);


                    cm.ExecuteNonQuery();
                }

                string query3 = "SELECT Company FROM Machine WHERE MachineName LIKE  @MachineName";

                SqlCommand com = new SqlCommand(query3, conn);
                com.Parameters.AddWithValue("@MachineName", machine);
                object var1 = com.ExecuteScalar();

                if (var1 != null)
                {
                    string company = var1.ToString();
                    string query4 = "INSERT INTO Machine (MachineID, MachineName, Company , TargetedMuscle, ExerciseID) VALUES (@MachineID, @MachineName, @Company, @TargetedMuscle, @ExerciseID)";

                    using (SqlCommand cm = new SqlCommand(query4, conn))
                    {

                        cm.Parameters.AddWithValue("@MachineID", randomnumber3);
                        cm.Parameters.AddWithValue("@MachineName", machine);
                        cm.Parameters.AddWithValue("@Company", company);
                        cm.Parameters.AddWithValue("@TargetedMuscle", muscle);
                        cm.Parameters.AddWithValue("@ExerciseID", randomnumber2);


                        cm.ExecuteNonQuery();
                    }

                    MessageBox.Show("WorkoutPlan Added ");
                }

            }

            this.Hide();
            TrainerWorkoutSchedule trainer = new TrainerWorkoutSchedule();
            trainer.Show();
        }
    }
}

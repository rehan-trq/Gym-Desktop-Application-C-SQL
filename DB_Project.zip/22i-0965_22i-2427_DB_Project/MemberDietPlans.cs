﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Proj
{
    public partial class MemberDietPlans : Form
    {
        public MemberDietPlans()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberCreateDietPlan M = new MemberCreateDietPlan();
            M.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            MemberUserDietPlan M = new MemberUserDietPlan();
            M.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            MemberTrainerDietPlan M = new MemberTrainerDietPlan();
            M.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Member h = new Member();
            h.Show();
        }
    }
}
